### 代码格式化压缩成一行教程
```text
npm install uglify-js -g
uglifyjs xx.js -o xx.min.js

配置webstorm
C:\Users\dashen\AppData\Roaming\npm\uglifyjs.cmd
$FileName$ -o $FileNameWithoutExtension$.min.js
$FileDir$
```

### 格式化教程
```text
vscode安装插件 prettier
webstorm安装插件 prettier
在设置里找到prettier配置保存时执行
对js文件右键，最下面的使用prettier重新格式化
```

### 自动函数参数注释教程
```text
在函数上方输入 /**然后回车即可
完结
```